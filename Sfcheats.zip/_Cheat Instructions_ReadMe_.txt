_RHF_Cheat_Instructions_ReadMe_

Xbox users can't use any of these. Play on a PC to take advantage. Your Xbox license will entitle a PC version.

PC Players: After you play Starfield all the way through without cheating, you should try the shortcuts available with cheat codes.
The game is highly re-playable if you don't have to grind. 
True, you will sacrifice "achievements", but you will have already earned them in your original playthrough, or learn to forget about them. You will see more content this way and get more value.
Build amazing ships and outposts. Credits (and skills) are no longer an obstacle. Do everything the game is made to do.

I have assembled my collection of bat files as a Zip. The scripts in  the attached "SfCheats.zip" should be expanded in your PC's  […documents/games/starfield/] directory. 
They are all text files. They are executed with PC console: (~) "bat [filename]" do NOT include the file extension in your command (don't add ".txt"). 
EXAMPLE: tap tilde (~) key, type "bat SfCheatAllNew" [enter], then [esc] to cancel console. The example script will give you enormous wealth and power with which to start the game.

IMHO one really should mod as well. These are my essentials.
(Creations): Some are pay to download. I wouldn't play without them.
	Darkstar Astrodynamics
		Better ships with ridiculously powerful weapons, and excellent outpost components.
	Auto-solve Temple Puzzles
		No temple grind for your first and then Barrett's mission. You will already have all the other powers at level 10 if you run my start scripts. (I hate temple grinds.)
	Luxurious Ship Habs
		Comfort and beauty in space! Yeah. A pool! The crew seems to love the pool.
	Shade's Deluxe Dynamic Boostpacks
		Essential for maximum fun. Read the instructions, and also buy the controller at one of the listed stores. Again: Read the instructions. 
		After you activate the backpack device, the control appears as a weapon. Put that in your favorites, activate to fly. Against author's recommended defaults, I make settings "no restrictions" to fly in towns. Just save first in case of regret.
		Once you  are a flier, take a high flight and conjure your favorite ship EXAMPLE:"Player.placeatme 000F3076", then fly to it's door, choose the door by scrolling, open the door with console command "unlock" and take over the ship. Any ship is yours for this minimal effort. You can afford to buy them now too, but this method lets you collect more types.
	Sub-orbital Shuttle SOS-8
		Fly above the fray. Essential for Sam's artifact mission and essential for Varuun DLC 'Shattered Space'. Companions make funny remarks about your flying skills.
	Skinthetics by Enhance!
		Give yourself the looks of your favorite NPC.
		Build a collection of attractive action figures to populate your habs and structures. (Skinthetica Mannequins)
		Change the looks of your companions to suit you better.
		Don't forget to save a copy of your start looks if you plan to go back. 
	Digipick Skip
		Open sesame! Spring all doors and locks with a touch. Essential.
	Paradiso Cabin as Outpost Structure - Redone
		Create comfortable places to crash for the NPCs that you assign to your outposts, (Lin and Heller at the least).
	Mattell's Cockpits and Bridges Crew Series.
		The lux habs don't give enough crew space. These make up for it, and mount more weapons.
	

Cheat "max fun" pointers:	

NEW GAME: Run "bat SFCheatAllNew" is a setup bat you should run when you first see daylight on your walk to see Barrett for the first time.
	Shoot some grenades into the pirate ship when it lands. Nobody else has to get hurt.
In NG+ games: run "bat SfCheatNGsetup" when you wake up on the Starborn ship.
	In both cases, organize your inventory right away. Build your "favorites" for quick access.
	Before you leave Vectera (new game) build a DSA Terminus in the out country. Alternatively you can do it on the moon just before facing the pirates at the building. Using terminus tools, Upgrade your Mark1 Space suit, helmet and pack. Add Dynamic Boost Pack III. 
	Build a new ship that is kick ass. Add the most powerful weapons. Now back to the mission...Drop right in on the pirates and blow them to smithereens.

	
Here are your available shortcuts in alphabetical order:
		○ Note: self-transports will work across the galaxy! Your ship won't come with you. You'll need access to a starport to fetch it, so "bat spaceport" might be handy.

	• Bat affinity - ~, highlight your companion and scroll until their name appears, then this command will advance or expedite them to the next companion dialog.
	• Bat Andreja - transports her to you
	• Bat Arsenal - transports you to the store in New Atlantis
	• Bat Barrett - transports him to you
	• Bat Cora - transports her to you
	• Bat Euphorika - transports you to the bar in Neon, close to the sleepcrate you need to search. 
	• Bat galbank - transports you to Galbank in New Atlantis. 
	• Bat Legrande - transports you to a store that is closest to the spaceport entrance in Neon
	• Bat Lodge - transports to the Lodge in New Atlantis
	• Bat looks - use Enhance! anywhere (for free). You might want to quicksave first as you can't un-uglify.
	• Bat lounge - transports you to the Astral Lounge in Neon
	• Bat Magsniper - get that gun
	• Bat Mars2nd - transports you to Cydonia's second floor at elevator
	• Bat MarsMain - transports you to the Cydonia main entrance (inside).
	• Bat Mast - transports you to the Mast district center
	• Bat Minerals - transports you to Midtown Minerals in Akila
	• Bat Novablast - get that gun
	• Bat Outland - transports you to this store in New Atlantis
	• Bat Redmile - transports you to Redmile (useful to fetch the evidence at the bar).
	• Bat Roach - transports Roach (bounty hunter) to you
	• Bat Rock - transports you to somewhere near the Rock at Akila
	• Bat Ryujin - transports you to the operations floor at Ryujin tower (Neon)
	• Bat Sam - transports Sam to you
	• Bat Sara - transports Sara to you
	• Bat Sauvage - transports you to Madam Sauvage's Place in Neon
	• Bat SfCheat20Ships - lets your ship inventory go to 20, go higher if you want
	• Bat SfCheatAddAid - adds all aid. You only need to keep four or five to thrive, so this is for foodies.
	• Bat SfCheatAddAllApparel - All the clothes appear in you inventory. Some multiples.
	• Bat SfCheatAddAmmo - adds all ammo in massive quantity
	• Bat SfCheatAddPowers - this one will be called from a setup BAT. Not for individual use.
	• Bat SfCheatAddPowersMefirst  - this one will be called from a setup BAT. Not for individual use.- called from a setup bat. 
	• Bat SfCheatAddResources - this one will be called from a setup BAT. Not for individual use.
	• Bat SfCheatAddSkinthetica - adds enough resources to craft 100 doses of skinthetica. Called from a setup bat.
	• Bat SfCheatAddWeapons - called from a setup bat.
	• Bat SfCheatAllNew - run this as after you have created your character when you wake from the first artifact.
	• Bat SfCheatBoomPopAdd - adds hard to find boom pops, use if you're a foodie and need them.
	• Bat SfCheatCompleteResearch - this one will be called from a setup BAT. Not for individual use.
	• Bat SfCheatMaxoutSkills - this one will be called from a setup BAT. Not for individual use.
	• Bat SfCheatNGsetup - run this as soon as you awaken as a Starborn
	• Bat SfCheatPerkPoints - adds 100 perk points (which you won't need if you ran the setup, which added all skills).
	• Bat SfCheatQE - adds 50 quantum essence. You already have 50 if you ran setup.
	• Bat SfCheatReactorParts - adds parts for two advanced reactors.
	• Bat SfCheatSetLevelAt40 - called from setup bat. Some building materials aren't available to you until 40
	• BatSfCheatShipyard - makes all shipyards carry all stuff. Not needed if you build and use an outpost with Darkstar Astrodynamics mod and Mattell's cockpits.
	• Bat Spaceport - transports you to New Atlantis' spaceport.
	• Bat Stroud - transports you to Stroud's offices in Neon (in the tower). Issa is there (Walter's better half). She's one of my skinthetica targets. Paste her looks on Sara!
	• Bat Unity - transports you to the Unity. Useful if your ships "build armillary" bugs out when it's time to go.
	• Bat Viewport - transports you to the bar in New Atlantis (by spaceport and the well)
	• Bat Walter - transports Walter to you
	• Bat Waterfall - transports you to a place you can jump down to the waterfall (for Sara's romance)


What to do if you try to commandeer a ship and get "Not Authorized!"
From <https://www.nexusmods.com/starfield/mods/2450> 

	 Left-click on the pilot seat you want to interact with. Scroll if there are multiple seats. Look for a seat with the keyword tag "FURN." Sometime if there are multiple FURN around then its a guessing game.

	• CallFunction"ObjectReference.BlockActivation" False False
	• (try it now)
	• else
	• GetSpaceship 00000014
	• TrySetPlayerHomeSpaceShip [SHIP REF ID]

Other Console Cheats:
• tgm - God Mode. Makes you invincible and gives you unlimited ammo.
• tim - Immortal Mode. You can take damage but your health will never hit 0.
• player.additem f [value] - You can acquire infinite money. 4 million is enough per playthrough.
• player.additem a [value] - Infinite Digipicks. Not needed with my recommended mod.
• player.setav carryweight 999999 - Infinite Carry Capacity.
• player.additem [item id] [value] - Spawns the specified item in your inventory.

•player.placeatme [item id] [value] - Spawns the specified item or creature in front of you, including ships. <<--This one is worthy of your time to experiment with.

Fly into the sky with a jetpack, call a ship and it will hang in the sky. Wiggle out of it if you're inside. Unlock it via the console and enter. Take off out of the sky!  Its yours! 

Ships you can placeatme:
Player.placeatme 0002C3BF	Venture III
Player.placeatme 0038D658	Autobahn III
Player.placeatme 000F3076	Narwahl
Player.placeatme 003A2E11	Dragonfire
See complete list at <https://www.ign.com/wikis/starfield/All_Ship_IDs> 

• player.setlevel [value] - Sets your character to the specified level.
• player.addperk [perk id] - Adds the specified skill, trait, or background.
• player.paycrimegold 0 0 [faction id] - Pay Off Bounties for a specific Faction. Mattel's cockpits have bounty stations.
• psb - Unlocks all 24 powers.
• tdetect - NPCs will no longer detect you in stealth.
• tcai - NPCs will no longer target and attack you.
• tcl - No Clip. Allows you to move through walls and other objects. <-- risky for game stability. Save first.
• tfc - Toggles freefly camera, allowing you to fly around.
• kah - Kills all hostile NPCs in the vicinity. <-- Very useful for boring slogs through well known locations.
• passtime [hours] - Passes the specified number of hours without a seat or bed.
• showlooksmenu player 1 - opens the Enhance! menu to modify your character.
• tm - Toggles the UI on and off.
• setforcespeechchallengealwayssucceed 1 - Make all speech challenges automatically succeed - there is a mod for this too.
• Mannequin Limit: set 3f4aee to 50


